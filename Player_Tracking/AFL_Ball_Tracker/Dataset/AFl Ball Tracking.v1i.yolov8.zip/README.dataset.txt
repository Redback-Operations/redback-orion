# AFl Ball Tracking > 2025-05-07 5:30pm
https://universe.roboflow.com/nfl-ball-tracking/afl-ball-tracking

Provided by a Roboflow user
License: CC BY 4.0

https://www.youtube.com/watch?v=nPZExfKdwvA
https://www.youtube.com/watch?v=rJdJKlmhiLw